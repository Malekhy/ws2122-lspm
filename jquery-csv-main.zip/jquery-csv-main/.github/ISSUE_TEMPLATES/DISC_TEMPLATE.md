# Topic

## What Does this Impact?

Write a brief description of how this discussion applies to jquery-csv.

## Notes

Optionally, compile notes from the discussion here.

## References

- [link](href)
